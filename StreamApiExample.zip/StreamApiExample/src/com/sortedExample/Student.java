package com.sortedExample;

public class Student {

	private Integer studentId;
	private Integer age;
	private String name;

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Student(Integer studentId, Integer age, String name) {
		this.studentId = studentId;
		this.age = age;
		this.name = name;
	}

	public Student() {
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", age=" + age + ", name=" + name + "]";
	}

}
